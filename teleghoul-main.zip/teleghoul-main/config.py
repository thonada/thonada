# Конфиг
command_prefixes = ['.','!','/']

ghoul_table_command = 'ghoul-c'

end_message = 'l l let me die' # Сообщение после конца цикла, если не нужно - оставляем пустым
messages_per_second = 7 # Для ghoul_spam
sleep_time_ghoul = 0.1 # Для ghoul_table 0.0825

# Линии ниже не трогать, сломается!

api_id = 1016382
api_hash = 'c27834e5683d50a9bacf835a95ec4763'

# Линии выше не трогать, сломается!
